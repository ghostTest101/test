import 'package:ecommerce_app/features/home/domain/model/products_model.dart';

import '../../../../common/network/api_base.dart';
import '../../../../common/network/api_config.dart';
import '../../../../common/network/dio_client.dart';
import '../../../../common/utilities/di.dart';

abstract class GetProductsDataSource {
  Future<ProductList> getProducts();
}

class GetProductsDataSourceImpl with ApiBase<ProductList>  implements GetProductsDataSource {
  final DioClient dioClient = getIt<DioClient>();

  @override
  Future<ProductList> getProducts() async {
    Map<String, String> queryParameters = <String, String>{};
    return await makeGetRequest(
        dioClient.dio.get(ApiConfig.getProducts, queryParameters: queryParameters),
        ProductList.fromJson);
  }

}
