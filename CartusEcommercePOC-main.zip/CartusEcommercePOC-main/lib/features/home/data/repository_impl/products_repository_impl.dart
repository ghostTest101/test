/// @file MeetingsRepositoryImpl
/// @description MeetingsRepositoryImpl - An implemention class for "MeetingsRepository" which is calling apis through corresponding datasource
import 'package:ecommerce_app/common/repository/repository_helper.dart';
import 'package:ecommerce_app/features/home/data/datasources/home_datasource.dart';
import 'package:ecommerce_app/features/home/domain/model/products_model.dart';
import 'package:ecommerce_app/features/home/domain/repository/product_repository.dart';
import 'package:dartz/dartz.dart';

class ProductsRepositoryImpl extends ProductRepository with RepositoryHelper<Product> {
  final GetProductsDataSource dataSource;

  ProductsRepositoryImpl({required this.dataSource});

  @override
  Future<Either<String, ProductList>> getProducts() async {
    return checkItemFailOrSuccess(dataSource.getProducts());
  }

}
