import 'package:dartz/dartz.dart';
import 'package:ecommerce_app/features/home/domain/model/products_model.dart';
import 'package:ecommerce_app/features/home/domain/usecases/get_products_usecase.dart';
import 'package:get/get.dart';

class ProductListViewModel extends GetxController with StateMixin<List<ProductList>> {
  final GetProductUseCase productUseCase;

  ProductListViewModel({required this.productUseCase});

  Future<void> getProducts() async {
    {
      change(null, status: RxStatus.loading());
      final Either<String, ProductList> failureOrSuccess =
      await productUseCase.fetchProducts();
      failureOrSuccess.fold(
            (String failure) {
          change(null, status: RxStatus.error(failure));
        },
            (ProductList productList) {
          if (productList != null) {
            if (productList.products.isEmpty) {
              change(null, status: RxStatus.empty());
            } else {
              change(null, status: RxStatus.success()
              );
            }
          } else {
            change(null, status: RxStatus.empty());
          }
        },
      );
    }
  }
}