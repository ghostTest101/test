import 'package:dartz/dartz.dart';
import '../model/products_model.dart';

abstract class ProductRepository {
  Future<Either<String, ProductList>> getProducts();
}