import 'package:dartz/dartz.dart';
import 'package:ecommerce_app/features/home/domain/model/products_model.dart';
import 'package:ecommerce_app/features/home/domain/repository/product_repository.dart';
import 'package:flutter/foundation.dart' show immutable;

@immutable
class GetProductUseCase  {
  final ProductRepository productRepository;

  const GetProductUseCase(this.productRepository);

  Future<Either<String, ProductList>> fetchProducts() async {
    return await productRepository.getProducts();
  }
}
