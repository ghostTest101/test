
import 'package:ecommerce_app/features/home/data/datasources/home_datasource.dart';
import 'package:ecommerce_app/features/home/data/repository_impl/products_repository_impl.dart';
import 'package:ecommerce_app/features/home/domain/usecases/get_products_usecase.dart';
import 'package:ecommerce_app/features/home/presentation/viewmodel/product_viewmodel.dart';
import 'package:ecommerce_app/features/home/domain/repository/product_repository.dart';
import 'package:get_it/get_it.dart';
import 'package:dio/dio.dart';

import '../network/dio_client.dart';

final getIt = GetIt.instance;

Future<void> init() async {
  //Meetings
  getIt.registerFactory(
        () => ProductListViewModel(
          productUseCase: getIt<GetProductUseCase>(),
    ),
  );
  getIt.registerLazySingleton(() => GetProductUseCase(getIt<ProductRepository>()));
  getIt.registerLazySingleton<ProductRepository>(
          () => ProductsRepositoryImpl(dataSource: getIt<GetProductsDataSource>()));
  getIt.registerLazySingleton<GetProductsDataSource>(
          () => GetProductsDataSourceImpl());

  // //Dio
  getIt.registerLazySingleton<DioClient>(() => DioClient(getIt<Dio>()));
  getIt.registerLazySingleton<Dio>(() => Dio());
}