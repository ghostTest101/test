// ignore_for_file: avoid_shadowing_type_parameters
import 'package:ecommerce_app/common/utilities/app_string.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart' show DioException;
import 'package:ecommerce_app/common/network/dio_exception.dart';

mixin RepositoryHelper<T> {
  Future<Either<String, List<T>>> checkItemsFailOrSuccess(
      Future<List<T>> apiCallback) async {
    try {
      final List<T> items = await apiCallback;
      return Right(items);
    } on DioException catch (e) {
      final errorMessage = DioExceptions.fromDioError(e).toString();
      return Left(errorMessage);
    }
  }

  Future<Either<String, T>> checkItemFailOrSuccess<T>(
      Future<T> apiCallback) async {
    // Check connectivity
    var connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      // Return Left with noInternet as an error
      return const Left(AppString.checkInternet);
    }

    try {
      final T item = await apiCallback;
      return Right(item);
    } on DioException catch (e) {
      final errorMessage = DioExceptions.fromDioError(e).toString();
      return Left(errorMessage);
    }
  }
}
