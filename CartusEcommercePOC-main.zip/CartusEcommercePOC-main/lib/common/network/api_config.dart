class ApiConfig {
  ApiConfig._();

  static const String baseUrl = "https://dummyjson.com/products/";
  static const Duration receiveTimeout = Duration(milliseconds: 25000);
  static const Duration connectionTimeout = Duration(milliseconds: 25000);
  static const String getCategories = 'categories';
  static const String getProducts = 'category/skincare';
  static const String getProductDetails = 'baseUrl(\$productId: String!) ';
}